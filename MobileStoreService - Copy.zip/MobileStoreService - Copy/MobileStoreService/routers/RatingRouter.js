﻿var express = require('express');
var RatingController = require('../Controllers/RatingController')();

RatingRouter = express.Router();

RatingRouter.use('/', function (req, res, next) {
    next();
});

RatingRouter.get('/Ratings/:productid', function (req, res){
    RatingController.GetRatingsByProductId(req, function () { 
        
    });
    res.status(200).send('From ratings');
});

module.exports = RatingRouter;