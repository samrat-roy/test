﻿var express = require('express');
var authentication = require('../common/authentication')();
var customerrouters = express.Router();

// Include the Customer Controller
var customercontroller = require('../Controllers/customercontroller')();

customerrouters.use(function (req, res, next) {
    next();
});




// Get all customer
customerrouters.get('/customer/all', function (req, res) {
    var user = authentication.ValidateToken(req, res, function (err, data) {
        if (err) {
            res.status(500).send('Internal Server Error');
        }
        else {
            if (data.Status == 200) {
                customercontroller.GetAllCustomer(req, res);
            }
            else {
                res.status(401).send('UnAuthrize');
            }
        }
    });    
    
});


// Get all customer
customerrouters.get('/customer/name/:name', function (req, res) {
    customercontroller.GetByName(req, res);
    
});

// Search customer by query
customerrouters.get('/customer/search', function (req, res) {
    customercontroller.Searchuser(req, res);
});

// Register new customer
customerrouters.post('/customer/register', function (req, res) {
    customercontroller.RegisterUser(req, res);
});

// Update customer
customerrouters.put('/customer/update', function (req, res) {
    res.send('add called');
});

// Delete customer
customerrouters.delete('/customer/delete', function (req, res) {
    res.send('add called');
});


module.exports = customerrouters;