﻿var CutomerData = require('../Models/CustomerSchema')();
var mongoose = require('mongoose');

var customerrepositroy = function () {
    var CustomerModel = mongoose.model('Customer', CutomerData.Customer);
    var GetAllCustomer = function (callback){
        CustomerModel.find({}, function (err, resultData) {                       
            callback(err,resultData);
        });
    }
    
    var GetUserByName = function (name, callback){
        var jsonData = {};
        jsonData["firstname"] = name;
        console.log(jsonData);
        CustomerModel.find(jsonData, function (err, resultData) {                       
            callback(err,resultData);
        });
    }
    
    var RegisterUser = function (req,callback){
        var instance = new CustomerModel();
        instance.firstname = req.body.firstname;
        instance.lastname = req.body.lastname;
        instance.email = req.body.email;
        instance.mobile = req.body.mobile;
        instance.save(function (err) {
            callback(err);
        });
    }
    var SearchUser = function (req, callback){
        var user_id = req.query.id;
        var firstname = req.query.firstname;
        var lastname = req.query.lastname;
        var mobile = req.query.mobile;
        var email = req.query.email;
        var str = {};
        if (user_id != undefined) {
            str["_id"] = user_id;
        }
        if (firstname != undefined) {
            str["firstname"] = firstname;
        }
        if (lastname != undefined) {
            str["lastname"] = lastname;
        }
        if (mobile != undefined) {
            str["mobile"] = mobile;
        }
        if (email != undefined) {
            str["email"] = email;
        }        
        
        CustomerModel.find(str, function (err, resultData) {
            callback(err, resultData);
        });

    }
    return {
        GetAllCustomer : GetAllCustomer,
        RegisterUser : RegisterUser,
        GetUserByName : GetUserByName,
        SearchUser : SearchUser
    }
};
module.exports = customerrepositroy;