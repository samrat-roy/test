﻿var repository = require('../repository/customerrepository')();

var customercontroller = function () {
    var GetAllCustomer = function (req, res) {
        repository.GetAllCustomer(function (err, data) {
            if (err) {
                res.status(500).send("Error reading data");
            }     
            res.status(200).send(data);
        });      
    }
    var RegisterUser = function (req, res){
        repository.RegisterUser(req, function (err) {
            
            if (err) {
                res.status(500).send("Error saving data");
            }
            res.status(200).send("Customer registation successful");
        });
    }
    var GetByName = function (req, res){
        repository.GetUserByName(req.params.name, function (err, data) {
            if (err) {
                res.status(500).send("Error reading data");
            }
            res.status(200).send(data);
        });

    }
    
    var SearchUser = function(req, res){

        repository.SearchUser(req, function (err, data) {
            if (err) {
                res.status(500).send("Error reading data");
            }
            res.status(200).send(data);
        });
    }
       
    return {
        GetAllCustomer : GetAllCustomer,
        RegisterUser : RegisterUser,
        GetByName : GetByName,
        Searchuser : SearchUser
    }    
}
module.exports = customercontroller; 