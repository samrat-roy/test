﻿


var RatingController = function () {

    var GetRatingsByProductId = function (req,callback){
        console.log("from rating");
    }

    return{
        GetRatingsByProductId : GetRatingsByProductId
    }


}

module.exports = RatingController;

