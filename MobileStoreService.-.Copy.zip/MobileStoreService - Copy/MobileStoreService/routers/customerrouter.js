﻿var express = require('express');
var customerrouters = express.Router();

// Include the Customer Controller
var customercontroller = require('../Controllers/customercontroller')();

customerrouters.use(function (req, res,next) {
    next();
});




// Get all customer
customerrouters.get('/customer/all', function (req, res) {
    customercontroller.GetAllCustomer(req, res);
});


// Get all customer
customerrouters.get('/customer/name/:name', function (req, res) {
    customercontroller.GetByName(req, res);
    
});

// Search customer by query
customerrouters.get('/customer/search', function (req, res) {
    customercontroller.Searchuser(req, res);
});

// Register new customer
customerrouters.post('/customer/register', function (req, res) {
    customercontroller.RegisterUser(req, res);
});

// Update customer
customerrouters.put('/customer/update', function (req, res) {
    res.send('add called');
});

// Delete customer
customerrouters.delete('/customer/delete', function (req, res) {
    res.send('add called');
});


module.exports = customerrouters;