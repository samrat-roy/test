﻿using Microsoft.Practices.ServiceLocation;
using Microsoft.Practices.Unity;
using Microsoft.Practices.Unity.Configuration;

namespace MobileStoreService
{
    public sealed class DependecyResolver : IDependecyResolver
    {
        private static DependecyResolver instance = null;
        private static readonly object padlock = new object();
        private IUnityContainer container = new UnityContainer();
        private DependecyResolver()
        {            
            container.LoadConfiguration();
            UnityServiceLocator locator = new UnityServiceLocator(container);
            ServiceLocator.SetLocatorProvider(() => locator);
          
        }
        public static DependecyResolver Instance
        {
            get
            {
                if (instance == null)
                {
                    lock (padlock)
                    {
                        if (instance == null)
                        {
                            instance = new DependecyResolver();
                        }
                    }
                }
                return instance;
            }
        }
        #region IDependecyResolver Members      
        public T LoadConfiguration<T>(string key)
        {
            var value = ServiceLocator.Current.GetInstance<T>(key);
            return value;
        }
        #endregion
    }

    public interface IDependecyResolver
    {
        T LoadConfiguration<T>(string key);
    }
}