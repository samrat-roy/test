﻿using MobileStore.Contract;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Web.Http;
using System.Xml;
using System.Xml.Serialization;

namespace MobileStoreService.Controllers
{
    public class IdentityController : ApiController
    {
        [HttpPost]
        [Route("api/CreatUser")]
        public IHttpActionResult CreateUser([FromBody] UserInfo userInfo)
        {
            if(userInfo == null)
            {
                return BadRequest("User information is incorrect");
            }

            try
            {
                IIdentityRepository repo = DependecyResolver.Instance.LoadConfiguration<IIdentityRepository>("IdentyRepository");
                if(repo == null)
                {
                    throw new Exception("Error reading unity");
                }

                userInfo.Password = Base64Encode(userInfo.Password);
                var result = repo.CreateUser(userInfo);
                if(result)
                {
                    return Ok<string>("User Created");
                }
                else
                {
                    return BadRequest("User Exist");
                }                
            }
            catch(Exception ex)
            {
                return InternalServerError(ex);
            }
            
        }

        [HttpPost]
        [Route("api/ValiadteToken")]
        public IHttpActionResult ValidateToken([FromBody] string token)
        {
            UserClaims userInfo = null;
            if (string.IsNullOrEmpty(token))
                return BadRequest("No token supplied");
            try
            {
                userInfo =(UserClaims) DeserializeBase64(Base64Decode(token));
            }
            catch
            {
                return Unauthorized();
            }

            try
            {
                IIdentityRepository repo = DependecyResolver.Instance.LoadConfiguration<IIdentityRepository>("IdentyRepository");
                if (repo == null)
                {
                    throw new Exception("Error reading unity");
                }
                UserClaims userClaims = repo.ValidateToken(userInfo);
                return Ok<UserClaims>(userClaims);
                
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }            
        }

        [HttpPost]
        [Route("issue/access")]
        public IHttpActionResult IssueAccessToken([FromBody] UserInfo userInfo) 
        {
            if(userInfo == null)
            {
                return BadRequest("User information is incorrect");
            }

            try
            {
                IIdentityRepository repo = DependecyResolver.Instance.LoadConfiguration<IIdentityRepository>("IdentyRepository");
                if (repo == null)
                {
                    throw new Exception("Error reading unity");
                }

                userInfo.Password = Base64Encode(userInfo.Password);
                userInfo.CreationDate = DateTime.Now;
                var claims = repo.IssueAccessToken(userInfo);
                if(claims == null)
                {
                    BadRequest("User not found");
                }

                string token = Base64Encode(SerializeBase64(claims));

                return Ok<string>(token);
            }
            
            catch(Exception ex)
            {
                return InternalServerError(ex);
            }
        }


        public static string SerializeBase64(object o)
        {
            // Serialize to a base 64 string
            byte[] bytes;
            long length = 0;
            MemoryStream ws = new MemoryStream();
            BinaryFormatter sf = new BinaryFormatter();
            sf.Serialize(ws, o);
            length = ws.Length;
            bytes = ws.GetBuffer();
            string encodedData = bytes.Length + ":" + Convert.ToBase64String(bytes, 0, bytes.Length, Base64FormattingOptions.None);
            return encodedData;
        }

        public static object DeserializeBase64(string s)
        {
            // We need to know the exact length of the string - Base64 can sometimes pad us by a byte or two
            int p = s.IndexOf(':');
            int length = Convert.ToInt32(s.Substring(0, p));

            // Extract data from the base 64 string!
            byte[] memorydata = Convert.FromBase64String(s.Substring(p + 1));
            MemoryStream rs = new MemoryStream(memorydata, 0, length);
            BinaryFormatter sf = new BinaryFormatter();
            object o = sf.Deserialize(rs);
            return o;
        }

        public string Base64Encode(string plainText)
        {
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(plainText);
            return System.Convert.ToBase64String(plainTextBytes);
        }

        public static string Base64Decode(string base64EncodedData)
        {
            var base64EncodedBytes = System.Convert.FromBase64String(base64EncodedData);
            return System.Text.Encoding.UTF8.GetString(base64EncodedBytes);
        }
    }

    [Serializable]
    public class Test
    {
        public int Roll { get; set; }

        public string Name { get; set; }
    }
}
