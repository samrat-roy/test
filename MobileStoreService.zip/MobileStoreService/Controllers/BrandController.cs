﻿using MobileStore.Contract;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MobileStoreService.Controllers
{
    public class BrandController : ApiController
    {
        [Route("api/Brand")]
        [HttpGet]
        public IHttpActionResult BrandDetails()
        {
            try
            {
                List<BrandMaster> brandMaster = null;

                // Todo : Resolve Reposity through unity

                var repo = DependecyResolver.Instance.LoadConfiguration<IBrandRepository>("SQLReposiory");

                if(repo == null)
                {
                    return InternalServerError(new Exception("Unable to reslove dependecy."));
                }

                brandMaster = repo.BrandDetails();

                if (brandMaster.Count() == 0)
                {
                    return NotFound();
                }

                return Ok<BrandMaster[]>(brandMaster.ToArray());
            }
            catch(Exception ex)
            {
                return InternalServerError(ex);
            }
        }

    }
}
