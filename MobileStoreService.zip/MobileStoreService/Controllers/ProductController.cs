﻿using MobileStore.Contract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MobileStoreService.Controllers
{
    public class ProductController : ApiController
    {
        [Route("api/ProductByBrand/{brandid}")]
        [HttpGet]
        public IHttpActionResult ProductsByBrand(int brandid)
        {
            if(brandid <= 0)
            {
                return BadRequest("Invalid brand");
            }

            try
            {
                var repo = DependecyResolver.Instance.LoadConfiguration<IProductRepository>("ProductSQLRepository");

                if (repo == null)
                {
                    return InternalServerError(new Exception("Unable to reslove unity"));
                }

                var result = repo.GetProductsByBrand(brandid);

                if(result.Count() == 0)
                {
                    return NotFound();
                }

                return Ok<ProductMaster[]>(result.ToArray());
            }
            catch(Exception ex)
            {
                return InternalServerError(ex);
            }
        }
    }
}
